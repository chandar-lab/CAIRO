#!/bin/bash
#SBATCH --account=rrg-bengioy-ad_gpu
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:1
#SBATCH --mem=100G
#SBATCH --time=2:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 194
python main.py  --batch_size 32  --model facebook/opt-1.3b --targeted_bias religious_ideology --prompting BOLD --paraphrasing_model prompts_gpt-35-turbo-16k_4 prompts_gpt-35-turbo-16k_5 --seed 1 
