#!/bin/bash
#SBATCH --account=rrg-bengioy-ad_gpu
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:1
#SBATCH --mem=100G
#SBATCH --time=2:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 233
python main.py  --batch_size 8  --model EleutherAI/gpt-j-6B --targeted_bias religious_ideology --prompting BOLD --paraphrasing_model prompts_gpt-35-turbo-16k_2 prompts_gpt-35-turbo-16k_3 --seed 2 
