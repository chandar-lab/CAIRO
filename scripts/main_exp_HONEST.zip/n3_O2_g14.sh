#!/bin/bash
#SBATCH --account=rrg-bengioy-ad_gpu
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:1
#SBATCH --mem=100G
#SBATCH --time=2:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 39
python main.py  --batch_size 32  --model facebook/opt-1.3b --targeted_bias gender --prompting HONEST --paraphrasing_model prompts_meta-llama_Llama-2-7b-chat-hf_4 prompts_meta-llama_Llama-2-7b-chat-hf_5 --seed 3 
