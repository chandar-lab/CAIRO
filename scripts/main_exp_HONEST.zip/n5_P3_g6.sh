#!/bin/bash
#SBATCH --account=rrg-bengioy-ad_gpu
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:1
#SBATCH --mem=100G
#SBATCH --time=2:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 11
python main.py  --batch_size 32  --model EleutherAI/pythia-410m --targeted_bias gender --prompting HONEST --paraphrasing_model prompts_mistralai_Mistral-7B-Instruct-v0.2_1 prompts_mistralai_Mistral-7B-Instruct-v0.2_2 --seed 5 
