#!/bin/bash
#SBATCH --account=rrg-bengioy-ad
#SBATCH --cpus-per-task=1

#SBATCH --mem=10G
#SBATCH --time=11:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 251.5
python collect_results.py  --experiment paraphrasing_effect  --paraphrasing_model Chatgpt_Llama_Mistral --prompting_list BOLD --model EleutherAI/pythia-160m --group race --split test