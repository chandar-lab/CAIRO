#!/bin/bash
#SBATCH --account=rrg-bengioy-ad
#SBATCH --cpus-per-task=1

#SBATCH --mem=10G
#SBATCH --time=11:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 163.0
python collect_results.py  --experiment paraphrasing_effect  --paraphrasing_model Chatgpt --prompting_list BOLD --model EleutherAI/pythia-410m --group gender --split valid