#!/bin/bash
#SBATCH --account=rrg-bengioy-ad
#SBATCH --cpus-per-task=1

#SBATCH --mem=10G
#SBATCH --time=11:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 241.5
python collect_results.py  --experiment paraphrasing_effect  --paraphrasing_model Llama --prompting_list BOLD --model EleutherAI/gpt-neo-2.7B --group gender --split test