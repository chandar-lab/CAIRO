#!/bin/bash
#SBATCH --account=rrg-bengioy-ad
#SBATCH --cpus-per-task=1

#SBATCH --mem=10G
#SBATCH --time=2:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 75.0
python compute_correlation.py --experiment collect_all_paraphrasing_models  --paraphrasing_model Llama --prompting BOLD HONEST holistic  --model facebook/opt-2.7b --group Gender --split valid