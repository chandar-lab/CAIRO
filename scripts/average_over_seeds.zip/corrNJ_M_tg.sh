#!/bin/bash
#SBATCH --account=rrg-bengioy-ad
#SBATCH --cpus-per-task=1

#SBATCH --mem=10G
#SBATCH --time=2:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 58.5
python compute_correlation.py --experiment collect_all_paraphrasing_models  --paraphrasing_model Mistral --prompting BOLD HONEST holistic  --model EleutherAI/gpt-j-6B --group Gender --split test