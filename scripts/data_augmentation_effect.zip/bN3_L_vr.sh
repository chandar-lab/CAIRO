#!/bin/bash
#SBATCH --account=rrg-bengioy-ad
#SBATCH --cpus-per-task=1

#SBATCH --mem=10G
#SBATCH --time=11:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 242.0
python collect_results.py  --experiment data_augmentation_effect  --paraphrasing_model Llama --prompting_list BOLD --model EleutherAI/gpt-neo-2.7B --group race --split valid