#!/bin/bash
#SBATCH --account=rrg-bengioy-ad
#SBATCH --cpus-per-task=1

#SBATCH --mem=10G
#SBATCH --time=11:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 104.0
python collect_results.py  --experiment data_augmentation_effect  --paraphrasing_model Llama --prompting_list holistic --model EleutherAI/pythia-410m --group religion --split valid