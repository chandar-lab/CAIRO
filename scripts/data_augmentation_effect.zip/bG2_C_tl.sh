#!/bin/bash
#SBATCH --account=rrg-bengioy-ad
#SBATCH --cpus-per-task=1

#SBATCH --mem=10G
#SBATCH --time=11:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 186.5
python collect_results.py  --experiment data_augmentation_effect  --paraphrasing_model Chatgpt --prompting_list BOLD --model gpt2 --group religious_ideology --split test