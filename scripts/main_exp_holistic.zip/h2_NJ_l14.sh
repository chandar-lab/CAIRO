#!/bin/bash
#SBATCH --account=rrg-bengioy-ad_gpu
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:1
#SBATCH --mem=100G
#SBATCH --time=23:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 159
python main.py  --batch_size 8  --model EleutherAI/gpt-j-6B --targeted_bias religion --prompting holistic --paraphrasing_model prompts_meta-llama_Llama-2-7b-chat-hf_4 prompts_meta-llama_Llama-2-7b-chat-hf_5 --seed 2 
