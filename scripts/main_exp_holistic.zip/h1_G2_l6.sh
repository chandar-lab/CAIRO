#!/bin/bash
#SBATCH --account=rrg-bengioy-ad_gpu
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:1
#SBATCH --mem=100G
#SBATCH --time=11:57:00
#SBATCH -o ./slurm-%j.out  # Write the log in $SCRATCH
sleep 147
python main.py  --model gpt2 --targeted_bias religion --prompting holistic --paraphrasing_model prompts_mistralai_Mistral-7B-Instruct-v0.2_1 prompts_mistralai_Mistral-7B-Instruct-v0.2_2 --seed 1 
